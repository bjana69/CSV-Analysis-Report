"""
Package initialisation for tests.  This allows pytest to discover the test
modules in this directory.
"""